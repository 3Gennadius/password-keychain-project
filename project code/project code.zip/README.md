# password-keychain-project
This repository is for the 3rd year project of our password wallet app
If the app doesn't run, check the requirements file and check that you have all those libraries installed
just use the command "pip install -r requirements.txt"
Also check the .env file, that contains all your backend database credentials, update them to match the one on your machine


